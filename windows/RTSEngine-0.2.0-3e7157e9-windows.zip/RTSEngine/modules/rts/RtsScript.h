// Lua scripting (Lua 5.4, third_party/lua): game mechanics written as scripts in the game folder,
// changed without rebuilding the engine. Reference for script authors: docs/scripting.md.
//
// Two sandboxes:
//  * Simulation scripts (rules/maps "scripts": ["scripts/x.lua"]) run inside the lockstep tick and
//    must replay exactly on every platform. Numbers: Lua integers plus `fx` values (Q47.16 Fixed as
//    userdata with arithmetic metamethods). Floats are kept out of the simulation at three levels:
//      1. float literals (1.5, 1e3, 0x1p4) are rejected when a file is loaded, with file:line;
//      2. every float arithmetic primitive of the VM (/, ^, float + - * % //, constant folding)
//         raises "float arithmetic is not allowed" (guard macros in third_party/lua/rts_luaconf.h);
//      3. every API call that takes a number accepts only integers or fx ("use fx() or integers").
//    `7 // 2` is integer division; fractional math is `fx(7) / 2`, `fx("1.25")`, `fx(3, 4)`.
//    The library is reduced to deterministic parts: no os/io/debug/package/load/dofile/collectgarbage/
//    next; math keeps integer functions only and math.random uses the simulation RNG; pairs() iterates
//    keys in sorted order (integers, then strings) so iteration never depends on hashing or history;
//    tostring() never shows addresses; string hashing and table.sort pivots are seeded with constants.
//    An instruction budget per tick (count hook) aborts runaway code; any error is logged with
//    file:line and disables that handler (deterministically: the flag is simulation state).
//  * View scripts (rules "viewScripts") are presentation only: normal Lua numbers, read-only queries,
//    notices / effects / sounds as requests drained by the host (modules/rts/view/RtsViewScript.h).
//
// Persistent script state: the global table `state` (and the trigger variables). It is serialized
// canonically (sorted keys; integers, fx, strings, booleans, nested tables) into the ScriptStore world
// resource after every tick, so it is hashed (RtsModule::hashState), copied by rollback snapshots and
// restored into the VM when a rollback rewinds the world. Globals are read-only after loading and
// file-level locals must not be mutated by handlers (that state would escape snapshots) - see docs.
// Replays re-run setup, so the VM is re-created identically from the same sources.
#pragma once
#include <climits>
#include <cstdint>
#include <functional>
#include <initializer_list>
#include <memory>
#include <string>
#include <vector>
#include "../../engine/core/ECS.h"
#include "../../engine/core/Fixed.h"
#include "../../engine/data/Json.h"

namespace rts { class Simulation; class Hasher; struct Command; }

namespace rts::game {

class RtsModule;
struct Rules;
struct EffectDef;
struct EffectCtx;

using ScriptReader = std::function<bool(const std::string& relativePath, std::string& out)>;

// Script state of a match (a World resource, present only in games with scripts).
struct ScriptStore {
    std::string state;                          // canonical serialization of the `state` table (flushed lazily:
                                                // before checksums, snapshots and saves - ScriptEngine::flush)
    uint64_t serial = 0;                        // epoch stamp written by the VM when it enters a tick: a different
                                                // value means the world was replaced (rollback / load), so the VM
                                                // restores `state` and the per-entity data from the world
    bool started = false;                       // "start" handlers ran
    std::vector<uint8_t> disabled;              // per handler: switched off after an error
    std::vector<std::string> disabledFns;       // functions called from data that failed (sorted)
    std::vector<std::vector<uint64_t>> inside;  // per area handler: entities inside (sorted)
    struct Timer { uint32_t tick = 0; uint32_t seq = 0; std::string fn, arg; }; // game.after(); arg serialized
    std::vector<Timer> timers;                  // sorted by (tick, seq)
    uint32_t timerSeq = 0;
    std::vector<uint32_t> cmdReady;             // script commands: tick each (player, command) is off cooldown
                                                // (index player * commands + command; empty until one is used)
    bool userScripts = false;                   // the game has its own simulation scripts: hashed only then (the
                                                // standard library keeps its state in the C++ GameState)
    void hash(Hasher& h) const;
};

// Per-entity Lua data (game.data(h)): canonical serialization of the entity's table, written when the
// table changed (flush), hashed through `hash`, saved with the world, gone with the entity.
struct ScriptData {
    std::string blob;
    uint64_t hash = 0;     // FNV-1a of blob (hashState feeds entity + hash)
    uint64_t serial = 0;   // VM write stamp (not saved, not hashed): the VM's cached table is current when equal
};

// Base stat overrides set by game.set_stat_base(h, stat, value): replace the unit type's base value
// before techs / levels / buffs apply (RtsModule::stat). Saved and hashed; only games with scripts read it.
struct ScriptStats {
    struct Entry { uint8_t stat = 0; Fixed base{}; };
    std::vector<Entry> list;
};

// A script-defined player command (rules "commands": {id: {...}}). Sent as kCmdScript: param = index
// in commands() (sorted by id), args = one int64 per scalar argument (points: x then z as raw fx; units
// and entities: packed handles; enums: value index; bools: 0 / 1), units = the selection.
struct ScriptArgDef {
    enum Kind : uint8_t { Int, Enum, Bool, Point, Unit, Entity };
    std::string name;
    Kind kind = Int;
    int64_t min = INT32_MIN, max = INT32_MAX, def = 0;   // Int range / default (Enum, Bool: index / 0-1)
    std::vector<std::string> values;                     // Enum
    bool own = false;                                    // Unit: must belong to the issuing player
    int slots() const { return kind == Point ? 2 : 1; }
};
struct ScriptCommandDef {
    std::string id, label, icon, hotkey, tip;
    std::vector<ScriptArgDef> args;
    std::vector<std::pair<uint16_t, Fixed>> cost;       // resource index, amount: paid when the handler accepts
    Fixed cooldown{};                                    // seconds per player
    std::vector<uint16_t> types;                         // "targets": selected unit types it is shown for / accepts
    uint64_t tags = 0;                                   //   ... or tags ("tag:x"); none of both = no units needed
    bool needUnits = false;                              // targets given: at least one matching own unit
    std::string fn;                                      // handler: global function (default on_command)
    int pick = -1;                                       // first Point / Unit / Entity arg: what a click fills in
    bool mapClick = false;                               // "mapClick": a plain left click / tap on the map sends it (pick = a point)
    bool card = true;                                    // "card": false = no button / hotkey (sent only by view scripts, HUD documents, MCP)
};
// The command a plain map click sends (rules "mapClick"), or -1. Commands are sorted by id; the first one wins.
int mapClickCommand(const std::vector<ScriptCommandDef>& commands);
// Parses rules "commands" (unknown types / tags / resources are reported in `errors`).
std::vector<ScriptCommandDef> parseScriptCommands(const Json& rules, const Rules& R, std::vector<std::string>* errors = nullptr);

struct ScriptLogEntry {
    bool error = false;
    uint32_t tick = 0;
    std::string text;                           // "scripts/x.lua:12: message" for errors
};

// Script files of a game: rules "scripts" + map "scripts" (view: rules "viewScripts" + map "viewScripts").
std::vector<std::string> scriptFiles(const Json& rules, const Json& map, bool view = false);
// Reads every script file (and the files they require()) with `read` into rules["$scriptSources"]
// ({path: text}), so the simulation can load them without file access (headless, server, tests).
// Without embedded sources the module has no scripts to run, so every loader that starts a
// simulation calls this next to applyTilesToMap. Returns false with `err` when a listed file is missing
// (the others are embedded anyway).
bool embedScripts(Json& rules, const Json& map, const ScriptReader& read, std::string* err);
// Compile without running: "" when fine, else "name:line: message". sim = simulation rules (float literals).
std::string checkScriptSyntax(const std::string& name, const std::string& text, bool sim = true);
// The API reference for agents and the editor (functions, events, rules) as JSON.
Json scriptApiReference();

// Systems implemented by the engine's standard Lua library (modules/rts/lua/<name>.lua defines
// std.<name>(tick)); a game overrides one with scripts/std/<name>.lua.
enum class StdFn : uint8_t { Victory, Waves, Triggers, AutoBuild, Sell, Count };

// The simulation VM of one match (owned by RtsModule). It always runs the standard library;
// game scripts (rules/map "scripts") are loaded on top.
class ScriptEngine {
public:
    explicit ScriptEngine(RtsModule& module);
    ~ScriptEngine();
    ScriptEngine(const ScriptEngine&) = delete;
    ScriptEngine& operator=(const ScriptEngine&) = delete;

    // Create the VM and run every file (errors are logged, never thrown).
    void load(Simulation& sim, const Json& rules, const Json& map);
    void tick(Simulation& sim);   // the "scripts" system (last in the tick)
    // A standard-library system (no instruction budget: engine code). Errors are logged once.
    // Extra integer arguments follow the tick (entities as packed handles).
    void callStd(Simulation& sim, StdFn fn, std::initializer_list<int64_t> args = {});
    bool hasUserScripts() const { return userScripts_; }
    // Writes the VM's `state` and changed entity data into the world (ScriptStore / ScriptData). Called
    // before checksums, rollback snapshots and saves; cheap when nothing changed.
    void flush(Simulation& sim);

    // Entry points for data: trigger condition / action {"type": "script", "fn": ...} and the ability
    // effect {"type": "script", "fn": ...} (queued, runs in this tick's scripts phase).
    bool callCondition(Simulation& sim, const std::string& fn, const Json& args, uint8_t player, Entity unit, Vec3 at);
    void callAction(Simulation& sim, const std::string& fn, const Json& args, uint8_t player, Entity unit, Vec3 at, const std::string& trigger);
    void queueEffect(const EffectDef& e, const EffectCtx& ctx, std::vector<Entity> targets);

    // Script commands (rules "commands"): definitions, and the kCmdScript handler (RtsModule::applyCommand).
    const std::vector<ScriptCommandDef>& commands() const { return commands_; }
    int findCommand(const std::string& id) const;
    void runCommand(Simulation& sim, const Command& cmd);
    // Seconds (fx) until `player` can use command `index` again (0 = ready).
    Fixed commandCooldown(Simulation& sim, uint8_t player, int index) const;

    // Before-hooks (G12): global functions of the game's scripts, looked up at load. The module calls them
    // only when hooks() has the bit, so games without them pay nothing.
    enum Hook : uint8_t { kHookDamage = 1, kHookCommand = 2, kHookBuild = 4, kHookTrain = 8, kHookCast = 16 };
    uint8_t hooks() const { return hooks_; }
    Fixed beforeDamage(Simulation& sim, Entity target, Entity source, uint8_t sourceOwner, Fixed amount, uint16_t dmgType);
    bool allowCommand(Simulation& sim, const Command& c);                         // before_command(player, cmd)
    bool allowBuild(Simulation& sim, uint8_t player, uint16_t type, Vec3 at, Entity builder);   // can_build
    bool allowTrain(Simulation& sim, uint8_t player, uint16_t type, Entity producer);           // can_train
    bool allowCast(Simulation& sim, Entity caster, int index, Entity target, Vec3 at);          // can_cast

    bool hasFunction(const std::string& name) const;
    const std::vector<ScriptLogEntry>& log() const { return log_; }
    int errorCount() const { return errors_; }
    // Log sink (editor console); called for every new entry.
    std::function<void(const ScriptLogEntry&)> onLog;

    struct Impl;
private:
    std::unique_ptr<Impl> impl_;
    std::vector<ScriptLogEntry> log_;
    std::vector<ScriptCommandDef> commands_;
    int errors_ = 0;
    bool userScripts_ = false;
    uint8_t hooks_ = 0;
    friend struct Impl;
};


// Development profiler of Lua script time (env RTS_LUA_PROFILE=<prefix>; off otherwise, no cost but one branch per
// count-hook call). The count hook (every 1000 instructions) samples the Lua stack when >= RTS_LUA_PROFILE_US
// (default 100) microseconds of wall time passed since the last sample and charges that time to the stack.
// Hosts bracket simulation steps with luaProfileTickBegin / luaProfileTickEnd; luaProfileWrite writes folded stacks
// (<prefix>.all.folded: every tick; <prefix>.slow.folded: ticks over RTS_LUA_PROFILE_SLOW ms, default 50;
// <prefix>.ticks.folded: the same per slow tick, first frame "tick N run R", R the write time in ms). Values are microseconds.
// RTS_LUA_PROFILE_LINES=1 adds each frame's executing line ("fn@file:defined#line"); RTS_LUA_PROFILE_SPLIT=text
// writes <prefix>.split: per tick "tick wall_us sampled_us us_of_stacks_containing_text".
bool luaProfileEnabled();
void luaProfileTickBegin();
void luaProfileTickEnd(uint64_t tick, int64_t us);
void luaProfileWrite();

} // namespace rts::game
