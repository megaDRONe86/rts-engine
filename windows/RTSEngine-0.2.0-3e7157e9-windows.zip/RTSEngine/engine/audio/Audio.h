// Audio: sound effects, music and voice for every platform (CoreAudio on macOS/iOS, AAudio /
// OpenSL ES on Android, Web Audio, WASAPI, ALSA/PulseAudio — through miniaudio's device layer).
//
// Presentation only: audio never touches the simulation and may use float and its own RNG.
// Everything a game sounds like comes from data (`audio.json`, see docs in README):
//
//   {
//     "volume": { "music": 0.6, "sfx": 1.0, "ui": 0.8, "voice": 1.0, "ambient": 0.7 },
//     "sounds": {
//       "sword":  { "files": ["sounds/sword1.ogg", "sounds/sword2.ogg"], "volume": 0.8,
//                   "pitch": [0.92, 1.08], "maxInstances": 3, "cooldown": 0.06 },
//       "alarm":  { "file": "voice/under_attack.ogg", "bus": "voice", "spatial": false, "priority": 10 },
//       "blip":   { "synth": { "wave": "square", "freq": [880, 440], "duration": 0.08 }, "bus": "ui" }
//     },
//     "music": { "menu": "music/menu.ogg", "match": { "files": ["music/a.ogg", "music/b.ogg"], "shuffle": true } }
//   }
//
// Files: WAV, OGG Vorbis, MP3, FLAC. Read through a caller-provided reader (the client passes
// platform::readContentFile, so Android assets / web preload / packs work unchanged).
//
// Threading: all public methods are called from the main thread. Mixing runs on the device's audio
// thread (or the browser's audio callback); the two sides talk through a command queue.
#pragma once
#include <cmath>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <vector>

namespace rts {
class Json;
}

namespace rts::audio {

enum class Bus : uint8_t { Sfx, Ui, Voice, Music, Ambient, Count };
const char* busName(Bus b);
bool busFromName(std::string_view name, Bus& out);

using SoundId = int;
constexpr SoundId kNoSound = -1;
using VoiceId = uint32_t;          // 0 = none
constexpr VoiceId kNoVoice = 0;

// Decoded sample data, 16-bit interleaved, at its own rate (the mixer resamples).
struct Clip {
    std::vector<int16_t> pcm;
    int channels = 1;
    int sampleRate = 44100;
    float rms = 1.0f;       // loudness of the content (set at load): used by the "quietest" steal mode
    size_t frames() const { return channels > 0 ? pcm.size() / size_t(channels) : 0; }
    float seconds() const { return sampleRate > 0 ? float(frames()) / float(sampleRate) : 0.0f; }
};

// How a positional sound fades with distance (world units, e.g. map cells).
enum class Rolloff : uint8_t { Inverse, Linear, Exponential };

struct DistanceDef {
    Rolloff model = Rolloff::Inverse;
    float minDistance = 12;   // full volume closer than this
    float maxDistance = 60;   // silent beyond this (the last 20 % of the range fades to zero)
    float rolloff = 1;        // steepness of the curve
    float air = 1;            // multiplier of the environment's air absorption (0 = keeps its highs)
    float reverb = 1;         // multiplier of the distance-dependent reverb send (0 = dry)
};

// "Distant sounds": the environment of a bank (its "spatial" section).
struct Environment {
    DistanceDef defaults;     // for sounds that don't override
    float airCutoff = 2500;   // Hz of the low-pass at max distance; 0 = no air absorption
    float rear = 0;           // 0..1: sources behind the listener get duller and a bit quieter
    float speedOfSound = 0;   // world units per second; > 0 delays distant sounds; 0 = off
    bool reverb = true;
    float reverbSize = 0.5f, reverbDamping = 0.5f;  // 0..1
    float reverbWet = 0.35f;                         // output level of the reverb
    float reverbNear = 0.05f, reverbFar = 0.6f;      // send at min / max distance
};

// Which playing sound makes room when a limit (maxInstances or a group's max) is reached.
//   oldest   - the one started first
//   farthest - the one farthest from the listener; a new sound farther than all of them is dropped
//              instead (a far explosion never cuts off a close one). Default.
//   quietest - the one quietest right now (distance, volume, fades); a new sound quieter than all
//              of them is dropped
//   none     - nothing is stopped: the new sound is dropped
enum class Steal : uint8_t { Oldest, Farthest, Quietest, None };
const char* stealName(Steal s);
bool stealFromName(std::string_view name, Steal& out);

constexpr int kMaxSoundGroups = 4;   // groups one sound can belong to

// Limits shared by several sounds ("groups" section): e.g. all melee impacts together.
struct SoundGroupDef {
    std::string name;
    int max = 0;              // voices at once (0 = no limit, only cooldown)
    float cooldown = 0;       // seconds between two starts of any sound in the group
    Steal steal = Steal::Farthest;
    bool wholeBus = false;    // every sound on `bus` belongs to the group ("bus": "sfx")
    Bus bus = Bus::Sfx;
};

struct SoundDef {
    std::string name;
    std::vector<std::shared_ptr<const Clip>> clips;  // variations, one picked per play
    float volume = 1.0f;
    float pitchMin = 1.0f, pitchMax = 1.0f;
    Bus bus = Bus::Sfx;
    int maxInstances = 4;   // at most this many of this sound at once (0 = no limit)
    Steal steal = Steal::Farthest;  // who makes room for maxInstances
    std::vector<int> groups;        // indices into the bank's groups (at most kMaxSoundGroups)
    float cooldown = 0.0f;  // seconds between two starts (stops 40 archers from firing 40 sounds)
    int priority = 0;       // when all voices are busy, lower priority is stolen first
    bool loop = false;
    bool spatial = true;    // attenuated and panned around the listener when played at a position
    DistanceDef distance;   // from the bank's "spatial" defaults plus the sound's own keys
    SoundId far = kNoSound; // distant variant crossfaded in towards max distance ("far")
    float duckMusic = 0;    // music is lowered by this fraction while the sound plays (voice: 0.4)
    uint8_t sync = 0;       // stingers: 0 now, 1 next beat, 2 next bar of the playing music
    float farFrom = 0.3f;   // fraction of the distance range where the crossfade starts
};

struct PlayParams {
    float volume = 1.0f;
    float pitch = 1.0f;     // multiplied with the sound's random pitch
    bool positional = false;
    float x = 0, y = 0, z = 0;  // world position (y = height)
    float pan = 0;          // -1 left .. 1 right: stereo balance (added to the 3D pan of a positional sound)
    int variant = -1;       // which of the sound's files (0-based); -1 = random, never the same twice in a row
    float startAt = 0;      // seconds into the clip
    int loop = -1;          // -1 = the sound's "loop", 0 / 1 override
};

// Live changes to a playing voice (AudioEngine::setVoice); NaN fields stay as they are.
struct VoiceParams {
    float volume = NAN;     // replaces PlayParams::volume (the sound's own volume stays a factor)
    float pan = NAN;        // replaces PlayParams::pan
    float pitch = NAN;      // absolute playback rate (replaces the random pitch)
};

// What the mixer last reported about a voice (AudioEngine::voiceState).
struct VoiceState {
    bool playing = false;   // started (or about to start) and not finished / stopped
    bool paused = false;
    float time = 0;         // seconds into the clip (the clip's own time, not scaled by pitch)
};

// The ear: position and orientation in the world. `hearing` scales every sound's distances (an
// RTS raises it when the camera zooms out, so the whole visible battlefield stays audible).
struct ListenerPose {
    float pos[3] = {0, 0, 0};
    float forward[3] = {0, 0, -1};
    float up[3] = {0, 1, 0};
    float hearing = 1;
};

struct AudioConfig {
    bool openDevice = true;  // false: silent engine driven by render() (tests, headless)
    int sampleRate = 0;      // 0 = device native (usually 48000)
    int maxVoices = 32;
    int periodMs = 0;        // 0 = backend default (~10 ms; larger on web)
    bool reverb = true;      // distance reverb (switch off on the weakest devices)
    bool nullBackend = false; // real audio thread without hardware (CI): miniaudio's null device
    std::string capturePath;  // debug: record everything the device plays into this WAV on shutdown
};

// Reads a content file (relative path) into `out`.
using FileReader = std::function<bool(const std::string& path, std::string& out)>;

class AudioEngine {
public:
    AudioEngine();
    ~AudioEngine();
    AudioEngine(const AudioEngine&) = delete;
    AudioEngine& operator=(const AudioEngine&) = delete;

    // Never fails hard: without an audio device the engine runs silently.
    void init(const AudioConfig& cfg = {});
    void shutdown();
    bool deviceOpen() const;
    bool running() const;    // commands reach a mixer (a device plays, or render() drives an offline engine)
    const std::string& deviceError() const;
    int sampleRate() const;

    // ---- data
    // Loads `audio.json` (replacing the previous bank). Returns false with a readable message on
    // malformed data; missing or undecodable files are only warnings (that sound stays silent).
    bool loadBank(const Json& bank, const FileReader& read, std::string* error = nullptr);
    void clearBank();
    SoundId find(std::string_view name) const;
    const SoundDef* sound(SoundId id) const;
    size_t soundCount() const;
    int findGroup(std::string_view name) const;   // -1 if unknown
    const SoundGroupDef* group(int index) const;
    size_t groupCount() const;
    const std::vector<std::string>& warnings() const;
    bool hasMusic(std::string_view name) const;

    // ---- playback
    VoiceId play(SoundId id, const PlayParams& p = {});
    VoiceId play(std::string_view name, const PlayParams& p = {}) { return play(find(name), p); }
    void stop(VoiceId v, float fadeSeconds = 0.05f);
    // busMask: bit (1 << Bus) of the buses whose voices stop (default every bus)
    void stopAll(float fadeSeconds = 0.1f, uint32_t busMask = ~0u);
    // Voice handles (scripts that run their own mixer: gain / pan / pitch every frame, pause, seek).
    void setVoice(VoiceId v, const VoiceParams& p);
    void pauseVoice(VoiceId v, bool paused);
    void seekVoice(VoiceId v, float seconds);
    // Last state reported by the mixer (one audio period behind); a voice whose start is still
    // queued counts as playing at its start time. Without a running mixer: not playing.
    VoiceState voiceState(VoiceId v) const;
    // Length in seconds of a sound's file (variant 0-based), 0 if unknown.
    float clipSeconds(SoundId id, int variant = 0) const;
    // The bank's "scripted": true — the game's scripts own the music and the UI sounds: the client
    // and RtsAudio never start or stop music by themselves and leaving a match keeps UI sounds.
    bool scripted() const;
    void setVoicePosition(VoiceId v, float x, float z) { setVoicePosition(v, x, 0, z); }
    void setVoicePosition(VoiceId v, float x, float y, float z);

    // Listener for positional sounds (3D).
    void setListener(const ListenerPose& pose);
    // Shortcut for a top-down view: an ear on the ground at (x, z) turned by `yaw`; `radius` is
    // where sounds with the default distances start to fade (hearing = radius / minDistance).
    void setListener(float x, float z, float yaw, float radius);
    const ListenerPose& listener() const;
    const Environment& environment() const;
    // 0..1: how loud a sound would be at that position (`id`: with its own distances, including
    // its far variant). Used to skip inaudible sounds.
    float audibility(float x, float z) const { return audibility(kNoSound, x, 0, z); }
    float audibility(SoundId id, float x, float y, float z) const;

    // ---- music (named playlists from the bank's "music" section, crossfaded)
    bool playMusic(std::string_view name, float fadeSeconds = 1.5f);
    void stopMusic(float fadeSeconds = 1.5f);
    const std::string& currentMusic() const;
    bool musicHasLayers(std::string_view name) const;
    // Adaptive music: 0..1 (smoothed over ~1.5 s). Layers fade in as it passes their "intensity".
    void setMusicIntensity(float v);
    float musicIntensity() const;
    // Script mix level of the music (ducking under other sounds): 0..4, multiplies the music bus.
    void setMusicGain(float v);
    float musicGain() const;

    // ---- volumes: user settings on top of the bank's mix (0..1)
    void setMasterVolume(float v);
    float masterVolume() const;
    void setVolume(Bus b, float v);
    float volume(Bus b) const;
    // On / off per bus, independent of the volume (a game's "music: OFF" keeps the slider value).
    void setBusEnabled(Bus b, bool on);
    bool busEnabled(Bus b) const;
    void setMuted(bool m);
    bool muted() const;
    // Background / focus loss: mobile apps must go quiet (and release the device on iOS/Android).
    void setPaused(bool p);
    bool paused() const;
    std::string saveSettings() const;            // small text blob, store in userDataDir
    void loadSettings(const std::string& text);

    // Once per frame on the main thread (time for cooldowns, settings, finished music).
    void update(double dt);

    // ---- offline / tests: mix `frames` of interleaved stereo float. Only valid without a device.
    void render(float* out, int frames);
    int activeVoices() const;   // snapshot from the mixer (approximate while a device runs)

    struct Impl;
private:
    std::unique_ptr<Impl> impl_;
};

// RMS of the clip's content, 0..1 (measured once when a bank loads).
float measureRms(const Clip& c);

// Decodes WAV/OGG/MP3/FLAC bytes into a Clip. Returns false with a reason.
bool decodeClip(const std::string& bytes, Clip& out, std::string& error);
// Same, converted on the way: `channels` 1 or 2 (0 = keep, surround is downmixed to stereo),
// `sampleRate` (0 = keep). Used by the build tools to downmix and resample before encoding.
bool decodeClipAs(const std::string& bytes, int channels, int sampleRate, Clip& out, std::string& error);

} // namespace rts::audio
